'use strict';
const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const fs = require('fs');
const path = require('path');
const csv = require('./src/csv');
const { XcsDriver, DEFAULT_LABELS } = require('./src/xcs');

// ---------- settings (userData/settings.json) ----------
const settingsFile = path.join(app.getPath('userData'), 'settings.json');
const settings = { port: 9222, xcsPath: '', targetMatch: '', labels: DEFAULT_LABELS, calibration: null };
try { Object.assign(settings, JSON.parse(fs.readFileSync(settingsFile, 'utf8'))); } catch { /* first run */ }
const saveSettings = () => {
  fs.mkdirSync(path.dirname(settingsFile), { recursive: true });
  fs.writeFileSync(settingsFile, JSON.stringify(settings, null, 2));
};
if (!fs.existsSync(settingsFile)) saveSettings();

const driver = new XcsDriver(settings);

// ---------- app state ----------
const state = {
  file: null, columns: null, headers: [], rows: [],
  running: false, stopAfterCurrent: false, current: null,
  message: '', calibrated: !!settings.calibration, settingsFile
};

let win;
const push = () => win?.webContents.send('state', state);

function loadCsv(file) {
  const { headers, records, columns } = csv.load(fs.readFileSync(file));
  state.file = file;
  state.headers = headers;
  state.columns = columns;
  state.rows = records.map((r, i) => ({
    n: i + 1,
    record: r,
    text: r[columns.text] ?? '',
    order: columns.order ? r[columns.order] : '',
    item: [columns.model && r[columns.model], columns.colour && r[columns.colour]].filter(Boolean).join(' · '),
    status: 'pending',
    msg: ''
  }));
  state.message = '';
  push();
}

function logRow(row) {
  if (!state.file) return;
  const out = state.file.replace(/\.csv$/i, '') + '.engraved.csv';
  const q = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
  if (!fs.existsSync(out)) fs.writeFileSync(out, '\uFEFFtime,row,order_id,engraving_text,status,message\n');
  fs.appendFileSync(out, [new Date().toISOString(), row.n, row.order, row.text, row.status, row.msg].map(q).join(',') + '\n');
}

async function run() {
  if (state.running) return;
  if (!settings.calibration) { state.message = 'Run "Teach position" first.'; return push(); }
  state.running = true;
  state.stopAfterCurrent = false;
  state.message = '';
  push();

  try {
    await driver.connect();
    for (const row of state.rows) {
      if (row.status === 'done' || row.status === 'skipped') continue;
      if (state.stopAfterCurrent) { state.message = 'Paused.'; break; }

      if (!String(row.text).trim()) {
        row.status = 'skipped'; row.msg = 'Empty engraving text'; logRow(row); push(); continue;
      }

      state.current = row.n;
      row.status = 'working'; row.msg = 'Writing text…'; push();
      try {
        await driver.setText(String(row.text), settings.calibration);
        await driver.runJob(phase => { row.msg = phase; push(); });
        row.status = 'done'; row.msg = '';
        logRow(row);
      } catch (e) {
        row.status = 'error'; row.msg = e.message; logRow(row);
        state.message = `Stopped at row ${row.n}: ${e.message}  Fix it and press Start to retry.`;
        break;
      }
      push();
    }
    if (state.rows.every(r => r.status === 'done' || r.status === 'skipped')) {
      state.message = `All done – ${state.rows.filter(r => r.status === 'done').length} engraved.`;
    }
  } catch (e) {
    state.message = e.message;
  } finally {
    state.running = false;
    state.current = null;
    push();
  }
}

// ---------- IPC ----------
ipcMain.handle('get-state', () => state);

ipcMain.handle('pick-csv', async () => {
  const r = await dialog.showOpenDialog(win, { filters: [{ name: 'CSV', extensions: ['csv', 'txt'] }], properties: ['openFile'] });
  if (!r.canceled) loadCsv(r.filePaths[0]);
});

ipcMain.handle('load-csv', (_e, file) => {
  try { loadCsv(file); } catch (e) { state.message = e.message; push(); }
});

ipcMain.handle('set-text-column', (_e, col) => {
  if (state.running || !state.headers.includes(col)) return;
  state.columns.text = col;
  state.rows.forEach(r => { r.text = r.record[col] ?? ''; });
  push();
});

ipcMain.handle('reset-row', (_e, n) => {
  const row = state.rows.find(r => r.n === n);
  if (row && !state.running) { row.status = 'pending'; row.msg = ''; push(); }
});

ipcMain.handle('xcs-status', () => driver.isReachable());

ipcMain.handle('launch-xcs', async () => {
  try {
    let exe = driver.findExe();
    if (!exe) {
      const r = await dialog.showOpenDialog(win, {
        title: 'Find XCS / xTool Studio (.exe)', filters: [{ name: 'Program', extensions: ['exe'] }], properties: ['openFile']
      });
      if (r.canceled) return;
      exe = settings.xcsPath = r.filePaths[0];
      saveSettings();
    }
    state.message = 'Starting XCS…'; push();
    await driver.launch(exe);
    state.message = 'XCS is connected. Open your template in XCS.';
  } catch (e) {
    state.message = e.message;
  }
  push();
});

let calibrationAbort = null;
ipcMain.handle('calibrate', async () => {
  if (state.running) return;
  calibrationAbort = new AbortController();
  try {
    settings.calibration = await driver.calibrate(step => win.webContents.send('calibrate-step', step), calibrationAbort.signal);
    saveSettings();
    state.calibrated = true;
    state.message = 'Position saved. Don’t move, resize or zoom the XCS canvas while running.';
  } catch (e) {
    state.message = e.message;
  }
  win.webContents.send('calibrate-step', null);
  push();
});
ipcMain.handle('calibrate-cancel', () => calibrationAbort?.abort());

ipcMain.handle('start', () => { run(); });
ipcMain.handle('pause', () => { state.stopAfterCurrent = true; push(); });

// ---------- window ----------
app.whenReady().then(() => {
  win = new BrowserWindow({
    width: 980, height: 760, minWidth: 720, minHeight: 560,
    title: 'Simple Batch Engraver',
    autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: false }
  });
  win.loadFile(path.join(__dirname, 'ui', 'index.html'));
});
app.on('window-all-closed', () => app.quit());
