'use strict';
const $ = (id) => document.getElementById(id);
const STATUS = { pending: 'Waiting', working: 'Engraving', done: 'Done', error: 'Error', skipped: 'Skipped' };
let current = null;

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function render(s) {
  current = s;
  const hasFile = !!s.file;
  $('drop').classList.toggle('compact', hasFile);
  $('drop').querySelector('strong').textContent = hasFile ? 'Load a different CSV' : 'Drop your CSV here';
  $('loaded').hidden = !hasFile;
  $('message').textContent = s.message || (s.calibrated ? '' : 'One-time setup: click "Teach position" (top right) before the first run.');

  if (hasFile) {
    $('fileName').textContent = s.file.split(/[\\/]/).pop();
    $('fileCount').textContent = ` · ${s.rows.length} rows`;

    const sel = $('textCol');
    if (sel.dataset.headers !== s.headers.join('|')) {
      sel.innerHTML = s.headers.map(h => `<option>${esc(h)}</option>`).join('');
      sel.dataset.headers = s.headers.join('|');
    }
    sel.value = s.columns.text;
    sel.disabled = s.running;

    $('rows').innerHTML = s.rows.map(r => `
      <tr class="${r.status}">
        <td>${r.n}</td>
        <td>${esc(r.order)}</td>
        <td>${esc(r.item)}</td>
        <td class="text">${esc(r.text)}</td>
        <td><span class="status ${r.status}">${STATUS[r.status]}</span>${
          (r.status === 'done' || r.status === 'error' || r.status === 'skipped') && !s.running
            ? `<button class="link retry" data-n="${r.n}">redo</button>` : ''
        }${r.msg && r.status !== 'working' ? `<div class="muted">${esc(r.msg)}</div>` : ''}</td>
      </tr>`).join('');

    const row = s.rows.find(r => r.n === s.current);
    $('now').hidden = !row;
    if (row) {
      $('nowText').textContent = row.text;
      $('nowMeta').textContent = [row.order && `Order ${row.order}`, row.item].filter(Boolean).join(' · ');
      $('nowPhase').textContent = row.msg;
      document.querySelector('tr.working')?.scrollIntoView({ block: 'nearest' });
    }

    const done = s.rows.filter(r => r.status === 'done').length;
    $('progress').textContent = `${done} of ${s.rows.length} engraved`;
  } else {
    $('progress').textContent = '';
  }

  const remaining = s.rows.some(r => r.status === 'pending' || r.status === 'error');
  $('startBtn').disabled = !hasFile || s.running || !remaining || !s.calibrated;
  $('startBtn').textContent = s.running ? 'Running…' : (s.rows.some(r => r.status !== 'pending') && remaining ? 'Continue' : 'Start');
  $('pauseBtn').hidden = !s.running;
  $('pauseBtn').disabled = s.stopAfterCurrent;
  $('pauseBtn').textContent = s.stopAfterCurrent ? 'Pausing after this one…' : 'Pause after this one';
  $('teachBtn').disabled = s.running;
}

// CSV in
const drop = $('drop');
drop.addEventListener('click', (e) => { e.preventDefault(); window.api.pickCsv(); });
drop.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') window.api.pickCsv(); });
drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
drop.addEventListener('dragleave', () => drop.classList.remove('over'));
drop.addEventListener('drop', (e) => {
  e.preventDefault(); drop.classList.remove('over');
  const f = e.dataTransfer.files[0];
  if (f && !current?.running) window.api.loadCsv(f);
});
document.addEventListener('dragover', (e) => e.preventDefault());
document.addEventListener('drop', (e) => e.preventDefault());

$('textCol').addEventListener('change', (e) => window.api.setTextColumn(e.target.value));
$('rows').addEventListener('click', (e) => {
  const b = e.target.closest('.retry');
  if (b) window.api.resetRow(Number(b.dataset.n));
});

// Run controls
$('startBtn').addEventListener('click', () => window.api.start());
$('pauseBtn').addEventListener('click', () => window.api.pause());

// XCS connection + one-time setup
$('launchBtn').addEventListener('click', () => window.api.launchXcs());
$('teachBtn').addEventListener('click', () => window.api.calibrate());
$('setupCancel').addEventListener('click', () => window.api.calibrateCancel());

window.api.onCalibrateStep((step) => {
  $('setup').hidden = !step;
  $('setupText').textContent = step === 'text'
    ? 'In XCS: double-click the text you want to replace.'
    : 'Now click an empty spot on the XCS canvas.';
});

async function pollXcs() {
  const ok = await window.api.xcsStatus();
  $('xcsPill').textContent = ok ? 'XCS connected' : 'XCS not connected';
  $('xcsPill').className = 'pill ' + (ok ? 'on' : 'off');
  $('launchBtn').hidden = ok;
}
setInterval(pollXcs, 3000);
pollXcs();

window.api.onState(render);
window.api.getState().then(render);
