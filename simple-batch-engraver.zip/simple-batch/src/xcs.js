'use strict';
// Drives XCS / xTool Studio through its debug port.
// Deliberately uses only the visible UI (mouse, keyboard, button labels) – no XCS internals –
// so it survives XCS updates better. Everything version-specific lives in settings.json.

const { spawn, execFile } = require('child_process');
const fs = require('fs');
const path = require('path');
const CDP = require('./cdp');

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const DEFAULT_LABELS = {
  process: ['Process', 'Обработка', 'Bearbeitung'],
  start: ['Start', 'Старт', 'Starten'],
  finish: ['Done', 'Finish', 'Complete', 'Готово', 'Fertig'],
  back: ['Back', 'Back to editor', 'Exit', 'Назад', 'Zurück']
};

function xcsCandidates() {
  const pf = process.env.ProgramFiles || 'C:\\Program Files';
  const local = process.env.LOCALAPPDATA || '';
  const names = [
    ['xTool Studio', 'xTool Studio.exe'],
    ['xTool Creative Space', 'xTool Creative Space.exe'],
    ['xTool Creative Space', 'XCS.exe']
  ];
  const roots = [pf, path.join(local, 'Programs')];
  return roots.flatMap(r => names.map(([dir, exe]) => path.join(r, dir, exe)));
}

// Runs inside XCS. Finds the top-most, visible, clickable element whose text matches one of the labels.
const FIND_BUTTON = `(labels) => {
  const norm = s => (s || '').replace(/\\s+/g, ' ').trim().toLowerCase();
  const want = labels.map(norm);
  let best = null;
  for (const el of document.querySelectorAll('button, [role="button"], a, div, span')) {
    if (!want.includes(norm(el.innerText))) continue;
    const btn = el.closest('button, [role="button"]') || el;
    const r = btn.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) continue;
    const cs = getComputedStyle(btn);
    if (cs.visibility === 'hidden' || cs.display === 'none' || Number(cs.opacity) === 0) continue;
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const top = document.elementFromPoint(cx, cy);
    if (!top || !(btn === top || btn.contains(top) || top.contains(btn))) continue; // covered by a modal
    const disabled = !!btn.disabled || btn.getAttribute('aria-disabled') === 'true' ||
      /(^|[\\s_-])(is-)?disabled\\b/i.test(String(btn.className));
    const score = (btn.tagName === 'BUTTON' ? 2 : 0) + (el.children.length === 0 ? 1 : 0);
    if (!best || score > best.score) best = { x: cx, y: cy, text: el.innerText.trim(), disabled, score };
  }
  return best;
}`;

class XcsDriver {
  constructor(settings) {
    this.settings = settings;
    this.cdp = null;
  }

  get port() { return this.settings.port || 9222; }
  get labels() { return { ...DEFAULT_LABELS, ...(this.settings.labels || {}) }; }

  // ---------- connection ----------
  async isReachable() {
    try { await CDP.listTargets(this.port, 800); return true; } catch { return false; }
  }

  async connect() {
    if (this.cdp && !this.cdp.closed) return this.cdp;
    if (!(await this.isReachable())) {
      throw new Error('XCS is not connected. Click "Launch XCS" in this app (close XCS first if it is already open).');
    }
    this.cdp = await CDP.connect(this.port, this.settings.targetMatch);
    return this.cdp;
  }

  findExe() {
    if (this.settings.xcsPath && fs.existsSync(this.settings.xcsPath)) return this.settings.xcsPath;
    return xcsCandidates().find(p => fs.existsSync(p)) || null;
  }

  isProcessRunning(exePath) {
    return new Promise(resolve => {
      if (process.platform !== 'win32' || !exePath) return resolve(false);
      execFile('tasklist', ['/FI', `IMAGENAME eq ${path.basename(exePath)}`, '/NH'], (err, out) => {
        resolve(!err && out.toLowerCase().includes(path.basename(exePath).toLowerCase()));
      });
    });
  }

  async launch(exePath) {
    if (await this.isReachable()) return;
    if (await this.isProcessRunning(exePath)) {
      throw new Error('XCS is already open without the debug connection. Close XCS completely, then click "Launch XCS" again.');
    }
    spawn(exePath, [`--remote-debugging-port=${this.port}`], { detached: true, stdio: 'ignore' }).unref();
    for (let i = 0; i < 60; i++) {
      await sleep(1000);
      if (await this.isReachable()) return;
    }
    throw new Error('XCS started, but the debug connection did not come up.');
  }

  // ---------- low-level input ----------
  async mouse(type, x, y, clickCount = 1) {
    await this.cdp.send('Input.dispatchMouseEvent', { type, x, y, button: 'left', clickCount });
  }

  async click(x, y) {
    await this.mouse('mouseMoved', x, y, 0);
    await this.mouse('mousePressed', x, y, 1);
    await this.mouse('mouseReleased', x, y, 1);
  }

  async doubleClick(x, y) {
    await this.click(x, y);
    await this.mouse('mousePressed', x, y, 2);
    await this.mouse('mouseReleased', x, y, 2);
  }

  async selectAll() {
    const ctrl = process.platform === 'darwin' ? 4 : 2;
    const key = { key: 'a', code: 'KeyA', windowsVirtualKeyCode: 65, modifiers: ctrl };
    await this.cdp.send('Input.dispatchKeyEvent', { type: 'keyDown', ...key, commands: ['selectAll'] });
    await this.cdp.send('Input.dispatchKeyEvent', { type: 'keyUp', ...key });
  }

  async findButton(kind) {
    return this.cdp.eval(`(${FIND_BUTTON})(${JSON.stringify(this.labels[kind])})`);
  }

  async waitForButton(kind, timeoutMs) {
    const end = Date.now() + timeoutMs;
    while (Date.now() < end) {
      const b = await this.findButton(kind);
      if (b && !b.disabled) return b;
      await sleep(400);
    }
    return null;
  }

  async clickButton(kind, timeoutMs) {
    const b = await this.waitForButton(kind, timeoutMs);
    if (!b) throw new Error(`Couldn't find the "${this.labels[kind][0]}" button in XCS. Check the label in settings.json.`);
    await this.click(b.x, b.y);
    return b;
  }

  async viewport() {
    return this.cdp.eval('({ w: innerWidth, h: innerHeight })');
  }

  // ---------- one-time setup: learn where the text and an empty canvas spot are ----------
  async calibrate(onStep, signal) {
    await this.connect();
    const cdp = this.cdp;
    await cdp.send('Runtime.addBinding', { name: '__sbeCapture' });
    await cdp.eval(`(() => {
      if (window.__sbeCal) return;
      const h = e => window.__sbeCapture(JSON.stringify({ type: e.type, x: e.clientX, y: e.clientY }));
      window.__sbeCal = h;
      document.addEventListener('dblclick', h, true);
      document.addEventListener('click', h, true);
    })()`);

    const cleanup = () => cdp.eval(`(() => {
      const h = window.__sbeCal; if (!h) return;
      document.removeEventListener('dblclick', h, true);
      document.removeEventListener('click', h, true);
      delete window.__sbeCal;
    })()`).catch(() => {});

    try {
      onStep('text');
      const result = await new Promise((resolve, reject) => {
        let text = null;
        let textAt = 0;
        const off = cdp.on('Runtime.bindingCalled', ({ name, payload }) => {
          if (name !== '__sbeCapture') return;
          const ev = JSON.parse(payload);
          if (ev.type === 'dblclick') {
            text = { x: ev.x, y: ev.y }; textAt = Date.now(); onStep('blank'); return;
          }
          if (!text) return;
          const near = Math.hypot(ev.x - text.x, ev.y - text.y) < 15;
          if (Date.now() - textAt < 700 || near) return; // part of the double-click
          off(); resolve({ text, blank: { x: ev.x, y: ev.y } });
        });
        signal?.addEventListener('abort', () => { off(); reject(new Error('Setup cancelled.')); });
        setTimeout(() => { off(); reject(new Error('Setup timed out. Try again.')); }, 180000);
      });
      const vp = await this.viewport();
      return { ...result, w: vp.w, h: vp.h };
    } finally {
      await cleanup();
    }
  }

  // ---------- per item ----------
  async setText(text, cal) {
    await this.connect();
    const vp = await this.viewport();
    if (vp.w !== cal.w || vp.h !== cal.h) {
      throw new Error('The XCS window size changed since setup. Restore it, or run "Teach position" again.');
    }
    await this.doubleClick(cal.text.x, cal.text.y);
    await sleep(400);
    await this.selectAll();
    await this.cdp.send('Input.insertText', { text });
    await sleep(200);
    await this.click(cal.blank.x, cal.blank.y); // leave text-edit mode
    await sleep(500);
  }

  async runJob(onPhase) {
    await this.connect();
    onPhase('Preparing job…');
    await this.clickButton('process', 30000);
    await this.clickButton('start', 60000);

    // The Start button should go away once XCS hands the job to the laser.
    const gone = Date.now() + 20000;
    while (await this.findButton('start')) {
      if (Date.now() > gone) throw new Error('XCS did not react to "Start". Is the laser connected and the lid closed?');
      await sleep(500);
    }

    onPhase('Place the item and press the button on the laser');
    // Wait (no time limit – the operator controls this) until XCS is back to a ready state.
    for (;;) {
      await sleep(1000);
      const fin = await this.findButton('finish');
      if (fin && !fin.disabled) { await this.click(fin.x, fin.y); continue; }
      if (await this.findButton('process')) return;           // back in the editor
      const start = await this.findButton('start');
      if (start && !start.disabled) break;                    // finished, still on the process screen
    }

    // Go back to the editor so the next text can be written.
    const end = Date.now() + 15000;
    while (Date.now() < end) {
      if (await this.findButton('process')) return;
      const b = (await this.findButton('finish')) || (await this.findButton('back'));
      if (b && !b.disabled) await this.click(b.x, b.y);
      await sleep(700);
    }
    throw new Error('Engraving finished, but XCS did not return to the editor. Check the "back" label in settings.json.');
  }
}

module.exports = { XcsDriver, DEFAULT_LABELS, FIND_BUTTON };
