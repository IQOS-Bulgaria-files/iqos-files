'use strict';
// Minimal Chrome DevTools Protocol client (uses Node's built-in fetch + WebSocket, no deps).

class CDP {
  constructor(ws, target) {
    this.ws = ws;
    this.target = target;
    this.nextId = 0;
    this.pending = new Map();
    this.listeners = new Map();
    this.closed = false;

    ws.addEventListener('message', (e) => {
      const msg = JSON.parse(e.data);
      if (msg.id && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        msg.error ? reject(new Error(msg.error.message)) : resolve(msg.result);
      } else if (msg.method) {
        (this.listeners.get(msg.method) || []).forEach(fn => fn(msg.params));
      }
    });
    ws.addEventListener('close', () => {
      this.closed = true;
      for (const p of this.pending.values()) p.reject(new Error('Connection to XCS was closed.'));
      this.pending.clear();
    });
  }

  static async listTargets(port, timeoutMs = 1500) {
    const res = await fetch(`http://127.0.0.1:${port}/json/list`, { signal: AbortSignal.timeout(timeoutMs) });
    return res.json();
  }

  static async connect(port, match) {
    const targets = await CDP.listTargets(port);
    const pages = targets.filter(t => t.type === 'page' && !t.url.startsWith('devtools://'));
    const target = (match && pages.find(p => (p.url + ' ' + p.title).includes(match))) || pages[0];
    if (!target) throw new Error('XCS is running, but no XCS window was found.');

    const ws = new WebSocket(target.webSocketDebuggerUrl);
    await new Promise((resolve, reject) => {
      ws.addEventListener('open', resolve, { once: true });
      ws.addEventListener('error', () => reject(new Error('Could not connect to the XCS window.')), { once: true });
    });
    const client = new CDP(ws, target);
    await client.send('Runtime.enable');
    return client;
  }

  send(method, params = {}) {
    if (this.closed) return Promise.reject(new Error('Connection to XCS was closed.'));
    const id = ++this.nextId;
    this.ws.send(JSON.stringify({ id, method, params }));
    return new Promise((resolve, reject) => this.pending.set(id, { resolve, reject }));
  }

  on(method, fn) {
    if (!this.listeners.has(method)) this.listeners.set(method, []);
    this.listeners.get(method).push(fn);
    return () => this.listeners.set(method, this.listeners.get(method).filter(f => f !== fn));
  }

  async eval(expression) {
    const r = await this.send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true });
    if (r.exceptionDetails) {
      throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
    }
    return r.result.value;
  }

  close() {
    try { this.ws.close(); } catch { /* ignore */ }
  }
}

module.exports = CDP;
