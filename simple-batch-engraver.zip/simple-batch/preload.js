'use strict';
const { contextBridge, ipcRenderer, webUtils } = require('electron');

contextBridge.exposeInMainWorld('api', {
  getState: () => ipcRenderer.invoke('get-state'),
  pickCsv: () => ipcRenderer.invoke('pick-csv'),
  loadCsv: (file) => ipcRenderer.invoke('load-csv', webUtils.getPathForFile(file)),
  setTextColumn: (col) => ipcRenderer.invoke('set-text-column', col),
  resetRow: (n) => ipcRenderer.invoke('reset-row', n),
  xcsStatus: () => ipcRenderer.invoke('xcs-status'),
  launchXcs: () => ipcRenderer.invoke('launch-xcs'),
  calibrate: () => ipcRenderer.invoke('calibrate'),
  calibrateCancel: () => ipcRenderer.invoke('calibrate-cancel'),
  start: () => ipcRenderer.invoke('start'),
  pause: () => ipcRenderer.invoke('pause'),
  onState: (fn) => ipcRenderer.on('state', (_e, s) => fn(s)),
  onCalibrateStep: (fn) => ipcRenderer.on('calibrate-step', (_e, s) => fn(s))
});
