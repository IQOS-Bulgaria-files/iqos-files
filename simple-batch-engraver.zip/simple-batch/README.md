# Simple Batch Engraver (xTool F1 / F1 Ultra + XCS)

One screen: drop a CSV → press **Start**. For each row the app writes the text into your
XCS template, clicks **Process → Start**, and waits for the operator to press the button
on the laser. When the job finishes it moves to the next row.

## Install / run

Requires Node.js 22+ on the build machine (Windows).

```
npm install
npm start            # run
npm run dist         # build a portable .exe into /dist
```

## Daily use

1. Click **Launch XCS** in the app (XCS must be started from here – it opens with the debug connection).
2. In XCS open your template (one text element, e.g. `NAME`). Tip: set the text alignment to **center**.
3. Drop the CSV into the app → **Start**.
4. For each row: place the item shown under *Now engraving*, press the button on the laser.

**Pause after this one** stops cleanly after the current item. Press **Continue** to resume –
rows already done are skipped. Click **redo** on any row to engrave it again.

Every result is appended to `<your-file>.engraved.csv` next to the source CSV.

## CSV

Header row required. Comma, semicolon or tab; UTF-8 or Windows-1251 (Excel/Cyrillic) are fine.
Columns detected automatically:

| Purpose | Column names looked for |
|---|---|
| Text to engrave | `engraving_text`, `engraving`, `text`, `value` (else first column; can be changed in the app) |
| Shown to operator | `order_id`, `model`, `colour` / `color` |

Rows with empty text are skipped and logged.

## One-time setup: Teach position

Click **Teach position**, then in XCS:
1. double-click the text you want to replace,
2. click an empty spot on the canvas.

The app saves both points. Don't move/resize the XCS window or pan/zoom the canvas afterwards
(the app checks the window size and stops if it changed). Re-run *Teach position* if you do.

## settings.json

Stored in `%APPDATA%\simple-batch-engraver\settings.json`.

| Key | What it does |
|---|---|
| `port` | XCS debug port (default 9222) |
| `xcsPath` | Path to the XCS / xTool Studio .exe (asked once if not found) |
| `labels.process` / `labels.start` | Button texts the app clicks. Match your XCS language/version. |
| `labels.finish` / `labels.back` | Buttons clicked after a job to get back to the editor |
| `calibration` | Saved by *Teach position* |

## Troubleshooting

Run `npm run probe` with XCS open (once in the editor, once on the Process screen).
It lists the visible buttons and which labels it matched, saved to `tools/probe-output.json`.
Fix `labels` in settings.json to match what XCS shows.
