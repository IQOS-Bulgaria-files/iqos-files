'use strict';
// Diagnostics: run while XCS is open (launched from the app) with your template loaded,
// then once more with the Process screen open. Writes probe-output.json next to this file.
//   node tools/probe.js            (Node 22+)
const fs = require('fs');
const path = require('path');
const CDP = require('../src/cdp');
const { FIND_BUTTON, DEFAULT_LABELS } = require('../src/xcs');

(async () => {
  const port = Number(process.argv[2]) || 9222;
  const targets = await CDP.listTargets(port).catch(() => {
    console.error(`Nothing on port ${port}. Launch XCS from the app first.`); process.exit(1);
  });
  const cdp = await CDP.connect(port);

  const page = await cdp.eval(`(() => {
    const vis = el => { const r = el.getBoundingClientRect(); return r.width > 1 && r.height > 1; };
    const clickable = [...document.querySelectorAll('button, [role="button"]')].filter(vis)
      .map(el => ({ text: el.innerText.trim().slice(0, 60), cls: String(el.className).slice(0, 80) }))
      .filter(b => b.text);
    return {
      title: document.title, url: location.href,
      viewport: { w: innerWidth, h: innerHeight },
      clickable,
      svgCount: document.querySelectorAll('svg').length,
      canvasCount: document.querySelectorAll('canvas').length,
      iframes: document.querySelectorAll('iframe').length,
      editable: [...document.querySelectorAll('textarea, input[type=text], [contenteditable=true]')].filter(vis).length
    };
  })()`);

  const labelHits = {};
  for (const [kind, labels] of Object.entries(DEFAULT_LABELS)) {
    labelHits[kind] = await cdp.eval(`(${FIND_BUTTON})(${JSON.stringify(labels)})`);
  }

  const out = { targets: targets.map(t => ({ type: t.type, title: t.title, url: t.url })), page, labelHits };
  const file = path.join(__dirname, 'probe-output.json');
  fs.writeFileSync(file, JSON.stringify(out, null, 2));
  console.log(JSON.stringify(out, null, 2));
  console.log(`\nSaved to ${file}`);
  cdp.close();
})();
